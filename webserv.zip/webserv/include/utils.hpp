/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rhanitra <rhanitra@student.42antananari    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/29 16:22:27 by rhanitra          #+#    #+#             */
/*   Updated: 2025/09/08 19:47:01 by rhanitra         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UTILS_HPP
#define UTILS_HPP

#include <stdexcept>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>

int ftToInt(const std::string &s);
std::string ftPutFileContent(const std::string& fileName);
std::vector<std::string> ftSplitStr(const std::string& str, const std::string& delimiter);

#endif
